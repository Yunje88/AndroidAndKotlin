package com.example.tutorials.androidguideapplication.viewmodel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.tutorials.androidguideapplication.databinding.ActivityViewmodelBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity
import com.example.tutorials.androidguideapplication.viewmodel.viewModel.MyViewModel

class ViewmodelActivity : AppCompatActivity() {

    lateinit var binding : ActivityViewmodelBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityViewmodelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var viewModel = ViewModelProvider(this).get(MyViewModel::class.java)

        binding.tvViewmodel.text = viewModel.num.toString()

        binding.btnViewModelNum.setOnClickListener {
            viewModel.num++
            binding.tvViewmodel.text = viewModel.num.toString()
        }

        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }

    }
}