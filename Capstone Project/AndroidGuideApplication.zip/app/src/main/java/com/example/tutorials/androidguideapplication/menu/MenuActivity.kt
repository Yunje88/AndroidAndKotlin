package com.example.tutorials.androidguideapplication.menu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tutorials.androidguideapplication.activity.ActivityActivity
import com.example.tutorials.androidguideapplication.coroutine.CoroutineActivity
import com.example.tutorials.androidguideapplication.databinding.ActivityMenuBinding
import com.example.tutorials.androidguideapplication.fragment.FragmentActivity
import com.example.tutorials.androidguideapplication.livedata.LiveDataActivity
import com.example.tutorials.androidguideapplication.mvvm.MvvmActivity
import com.example.tutorials.androidguideapplication.recyclerview.RecyclerviewActivity
import com.example.tutorials.androidguideapplication.room.RoomActivity
import com.example.tutorials.androidguideapplication.sqlite.SqliteActivity
import com.example.tutorials.androidguideapplication.viewmodel.ViewmodelActivity

class MenuActivity : AppCompatActivity() {

    lateinit var binding : ActivityMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        with(binding){
            btnActivity.setOnClickListener{ setView(1) }
            btnFragment.setOnClickListener{ setView(2) }
            btnViewmodel.setOnClickListener{ setView(3) }
            btnLivedata.setOnClickListener{ setView(4) }
            btnRecyclerview.setOnClickListener{ setView(5) }
            btnMvvm.setOnClickListener{ setView(6) }
//            btnCoroutine.setOnClickListener { setView(7) }
            btnRoom.setOnClickListener { setView(8) }
            btnSqlite.setOnClickListener { setView(9) }
        }

    }

    private fun setView(view: Int) {
        var intent : Intent

        when(view){
            1 -> { intent = Intent(this, ActivityActivity::class.java)
                startActivity(intent)}
            2 -> { intent = Intent(this, FragmentActivity::class.java)
                startActivity(intent)}
            3 -> { intent = Intent(this, ViewmodelActivity::class.java)
                startActivity(intent)}
            4 -> { intent = Intent(this, LiveDataActivity::class.java)
                startActivity(intent)}
            5 -> { intent = Intent(this, RecyclerviewActivity::class.java)
                startActivity(intent)}
            6 -> { intent = Intent(this, MvvmActivity::class.java)
                startActivity(intent)}
            7 -> { intent = Intent(this, CoroutineActivity::class.java)
                startActivity(intent)}
            8 -> { intent = Intent(this, RoomActivity::class.java)
                startActivity(intent)}
            9 -> { intent = Intent(this, SqliteActivity::class.java)
                startActivity(intent)}
        }


    }
}