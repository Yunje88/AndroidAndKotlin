package com.example.tutorials.androidguideapplication.recyclerview.recyclerview

data class Memo (
    var no:Int,
    var title:String,
    var timestamp:Long
        )