package com.example.tutorials.androidguideapplication.room.room

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "room_memo")
class RoomMemo {
    @PrimaryKey(autoGenerate = true) // if no is null, it automatically put some no
    @ColumnInfo
    var no: Long? = null
    @ColumnInfo
    var content: String = ""
    @ColumnInfo(name = "date")
    var datetime: Long = 0

    constructor(content:String, datetime:Long){
        this.content = content
        this.datetime = datetime
    }
}