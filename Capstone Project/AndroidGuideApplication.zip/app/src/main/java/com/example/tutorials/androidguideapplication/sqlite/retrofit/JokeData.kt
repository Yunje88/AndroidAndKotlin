package com.example.tutorials.androidguideapplication.sqlite.retrofit

import com.google.gson.annotations.SerializedName

data class JokeData (
    @SerializedName("joke")
    val joke: String = ""
)