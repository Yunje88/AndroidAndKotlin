package com.example.tutorials.androidguideapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tutorials.androidguideapplication.databinding.ActivityActivityBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity

class ActivityActivity : AppCompatActivity() {

    lateinit var binding: ActivityActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }

    }
}