package com.example.tutorials.androidguideapplication.fragment

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tutorials.androidguideapplication.R
import com.example.tutorials.androidguideapplication.databinding.ActivityFragmentBinding
import com.example.tutorials.androidguideapplication.fragment.fragment.FragmentOne
import com.example.tutorials.androidguideapplication.fragment.fragment.FragmentTwo
import com.example.tutorials.androidguideapplication.menu.MenuActivity

class FragmentActivity : AppCompatActivity() {

    lateinit var binding : ActivityFragmentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityFragmentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnFragmentone.setOnClickListener {
            setFragmentView(1)
        }
        binding.btnFragmenttwo.setOnClickListener {
            setFragmentView(2)
        }

        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }

    }

    private fun setFragmentView(view: Int) {
        var fragmentView = supportFragmentManager.beginTransaction()
        when(view){
            1 -> { fragmentView.replace(R.id.frame_fragment, FragmentOne()).commit() }
            2 -> { fragmentView.replace(R.id.frame_fragment, FragmentTwo()).commit()}
        }
    }


}