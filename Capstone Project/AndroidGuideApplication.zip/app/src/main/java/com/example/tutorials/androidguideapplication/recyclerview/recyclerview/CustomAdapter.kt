package com.example.tutorials.androidguideapplication.recyclerview.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorials.androidguideapplication.R
import java.text.SimpleDateFormat

class CustomAdapter : RecyclerView.Adapter<Holder>(){

    var listData = mutableListOf<Memo>()

    // initiate first 10 lists
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return Holder(itemView)
    }

    // add more lists
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val memo = listData.get(position)
        holder.setMemo(memo)
    }

    // get item size from our data
    override fun getItemCount(): Int {
        return listData.size
    }
}

    // custom holder for recyclerview
class Holder(itemView: View): RecyclerView.ViewHolder(itemView) {

    fun setMemo(memo:Memo){
        val textNo = itemView.findViewById<TextView>(R.id.textNo)
        textNo.text = "${memo.no}"
        val textTitle = itemView.findViewById<TextView>(R.id.textTitle)
        textTitle.text = memo.title
        val textDate = itemView.findViewById<TextView>(R.id.textDate)
        val sdf = SimpleDateFormat("yyyy/MM/dd")
        val date = sdf.format(memo.timestamp)
        textDate.text = date
    }
}