package com.example.tutorials.androidguideapplication.room

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.tutorials.androidguideapplication.databinding.ActivityRoomBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity
import com.example.tutorials.androidguideapplication.room.room.RecyclerAdapter
import com.example.tutorials.androidguideapplication.room.room.RoomHelper
import com.example.tutorials.androidguideapplication.room.room.RoomMemo

class RoomActivity : AppCompatActivity() {

    val binding by lazy { ActivityRoomBinding.inflate(layoutInflater)}
    lateinit var helper:RoomHelper
    lateinit var memoAdapter:RecyclerAdapter
    val memoList = mutableListOf<RoomMemo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar!!.hide()

        helper = Room.databaseBuilder(this, RoomHelper::class.java, "room_db")
            .allowMainThreadQueries()
            .build()

        memoList.addAll(helper.roomMemoDao().getAll())

        memoAdapter = RecyclerAdapter(memoList)

        with(binding){
            recyclerMemo.adapter = memoAdapter
            recyclerMemo.layoutManager = LinearLayoutManager(this@RoomActivity)

            buttonSave.setOnClickListener {
                val content = editMemo.text.toString()
                if(content.isNotEmpty()){
                    val datetime = System.currentTimeMillis()
                    val memo = RoomMemo(content, datetime)
                    helper.roomMemoDao().insert(memo)

                    memoList.clear()
                    memoList.addAll(helper.roomMemoDao().getAll())
                    memoAdapter.notifyDataSetChanged()
                }
            }
        }


        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }

}