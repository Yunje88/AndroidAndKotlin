package com.example.tutorials.androidguideapplication.sqlite

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.tutorials.androidguideapplication.databinding.ActivitySqliteBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity
import com.example.tutorials.androidguideapplication.sqlite.retrofit.JokeData
import com.example.tutorials.androidguideapplication.sqlite.retrofit.JokeService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class SqliteActivity : AppCompatActivity() {

    lateinit var binding: ActivitySqliteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivitySqliteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGetJoke.setOnClickListener {
            setRetrofit()
        }

        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setRetrofit() {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://v2.jokeapi.dev/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(JokeService::class.java)

        val call: Call<JokeData> =service.ApiService()
        call.enqueue(object: Callback<JokeData> {
            override fun onResponse(
                call: Call<JokeData>,
                response: Response<JokeData>
            ) {
                binding.tvApi.text = response.body()?.joke.toString()
                Log.d(ContentValues.TAG,"${response.body()?.joke}")
            }

            override fun onFailure(call: Call<JokeData>, t: Throwable) {
                Log.e(ContentValues.TAG, "FAIL")

            }
        })
    }
}