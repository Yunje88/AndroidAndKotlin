package com.example.tutorials.androidguideapplication.livedata

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.tutorials.androidguideapplication.databinding.ActivityLiveDataBinding
import com.example.tutorials.androidguideapplication.livedata.livedata.LiveDataViewModel
import com.example.tutorials.androidguideapplication.menu.MenuActivity

class LiveDataActivity : AppCompatActivity() {

    lateinit var binding: ActivityLiveDataBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityLiveDataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(this).get(LiveDataViewModel::class.java)

        viewModel.seconds().observe(this, Observer {
            binding.tvTimeNum.text = it.toString()
        })

        viewModel.finished.observe(this, Observer{
            if(it){
                Toast.makeText(this, "Finished", Toast.LENGTH_SHORT).show()
            }
        })

        binding.btnStartTimer.setOnClickListener {
            if(binding.edNumber.text.isEmpty() || binding.edNumber.text.length <4) {
                Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show()
            }else{
                viewModel.timerValue.value = binding.edNumber.text.toString().toLong()
            }
            viewModel.startTimer()
        }

        binding.btnStopTimer.setOnClickListener {
            viewModel.stopTimer()
            binding.edNumber.setText("0")
            Toast.makeText(this, "Time Stop", Toast.LENGTH_SHORT).show()
        }



        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }
}