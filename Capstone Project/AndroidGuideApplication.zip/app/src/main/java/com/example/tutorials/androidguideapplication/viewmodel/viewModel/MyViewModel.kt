package com.example.tutorials.androidguideapplication.viewmodel.viewModel

import androidx.lifecycle.ViewModel

class MyViewModel: ViewModel() {
    var num = 0

    fun addNum(){
        num++
    }

}