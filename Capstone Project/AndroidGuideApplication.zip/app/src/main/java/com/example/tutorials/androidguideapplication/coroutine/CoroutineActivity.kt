package com.example.tutorials.androidguideapplication.coroutine

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tutorials.androidguideapplication.databinding.ActivityCoroutineBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity

class CoroutineActivity : AppCompatActivity() {

    lateinit var binding : ActivityCoroutineBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityCoroutineBinding.inflate(layoutInflater)
        setContentView(binding.root)




        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }
}