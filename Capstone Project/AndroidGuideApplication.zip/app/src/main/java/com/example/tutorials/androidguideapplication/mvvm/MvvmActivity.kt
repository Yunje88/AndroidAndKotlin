package com.example.tutorials.androidguideapplication.mvvm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tutorials.androidguideapplication.R
import com.example.tutorials.androidguideapplication.databinding.ActivityMvvmBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity
import com.example.tutorials.androidguideapplication.mvvm.designpattern.*

class MvvmActivity : AppCompatActivity() {

    lateinit var binding: ActivityMvvmBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityMvvmBinding.inflate(layoutInflater)
        setContentView(binding.root)


        with(binding){
            btnMVVM.setOnClickListener {
                setView(1)
            }
            btnMVC.setOnClickListener {
                setView(2)
            }
            btnMVI.setOnClickListener {
                setView(3)
            }
            btnMVP.setOnClickListener {
                setView(4)
            }
        }


        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setView(view: Int) {
        var fragmentView = supportFragmentManager.beginTransaction()
        when(view){
            1 -> { fragmentView.replace(R.id.designframe, DesignMvvm()).commit() }
            2 -> { fragmentView.replace(R.id.designframe, DesignMvc()).commit() }
            3 -> { fragmentView.replace(R.id.designframe, DesignMvi()).commit() }
            4 -> { fragmentView.replace(R.id.designframe, DesignMvp()).commit() }
        }
    }
}