package com.example.tutorials.androidguideapplication.recyclerview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorials.androidguideapplication.databinding.ActivityRecyclerviewBinding
import com.example.tutorials.androidguideapplication.menu.MenuActivity
import com.example.tutorials.androidguideapplication.recyclerview.recyclerview.CustomAdapter
import com.example.tutorials.androidguideapplication.recyclerview.recyclerview.Memo

class RecyclerviewActivity : AppCompatActivity() {

    lateinit var binding : ActivityRecyclerviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        binding = ActivityRecyclerviewBinding.inflate(layoutInflater)
        setContentView(binding.root)


        // 1. load data
        val data = loadData()

        // 2. create Adapter
        val adapter = CustomAdapter()

        // 3. put data into the custom adapter
        adapter.listData = data

        // 4. connect recyclerview to adapter
        binding.recyclerView.adapter = adapter
        // 5. setup the layout manager
        binding.recyclerView.layoutManager = LinearLayoutManager(this)


        binding.btnActivity.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }

    fun loadData(): MutableList<Memo>{
        val data : MutableList<Memo> = mutableListOf()

        for(no in 1..30){
            val title = "Android Developer ${no}"
            val date = System.currentTimeMillis()

            val memo = Memo(no, title, date)
            data.add(memo)
        }

        return data
    }
}